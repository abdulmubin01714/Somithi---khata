# সমিতি খাতা 2008-10 — Android App

এই project আপনার GitHub Pages-এর Somithi Khata ওয়েব অ্যাপকে Android WebView অ্যাপে প্যাকেজ করে।

URL:
https://abdulmubin01714.github.io/Somithi---khata/

APK বানাতে Android Studio-তে project folder খুলে:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

নোট: এই wrapper APK নিজে Firebase database তৈরি/নিরাপদ করে না। ওয়েব অ্যাপের Firebase configuration এবং Firestore/Realtime Database Security Rules সঠিক থাকতে হবে, নইলে ডাটা হারানোর সমস্যা থেকেই যাবে।
